Santa Helper 2023 Sauerbraten mod by @SalatielSauer (salatielsauer.github.io)
The mod distributed alongside this file adds Santa hat and other Christmas ornaments to the models listed below.

-

Mr. Fixit conceptualized, modeled and animated by geartrooper a.k.a. John Siar ironantknight@gmail.com
Mr. Fixit textures, normal maps and displacement by Acord a.k.a Anthony Cord tonycord@gmail.com
mask textures by Nieb
Geartrooper would like to thank Stacy for her love, support and trust. He would like to thank lee salzman a.k.a. eihrul for his support and suggestions, without which much of mr fixit would not be possible.
Mr. Fixit is hereby released under the CC-BY-NC (Creative Commons Attribution Non-Commercial) license. See http://creativecommons.org/licenses/by-nc/3.0/legalcode for more info. Please contact Geartrooper for permission for uses not within the scope of this license.

-

Inky is hereby released under the CC-BY-NC (Creative Commons Attribution Non-Commercial) license. See http://creativecommons.org/licenses/by-nc/3.0/legalcode for more info. Please contact Geartrooper for permission for uses not within the scope of this license.

-

Captain Cannon is hereby released under the CC-BY-NC (Creative Commons Attribution Non-Commercial) license. See http://creativecommons.org/licenses/by-nc/3.0/legalcode for more info. Please contact Geartrooper for permission for uses not within the scope of this license.

-

IronSnout X10K is hereby released under the following license:
(C) John 'geartrooper' Siar
License: CC-BY 3.0 http://creativecommons.org/licenses/by/3.0/
Please contact Geartrooper for permission for uses not within the scope of this license.

-

Ogro2 Rigged and re-animated for skeletal animation by Geartrooper a.k.a. John Siar.
Original license follows:
10/11/98
================================================================
Model Name              : Ogro
installation directory  : quake2/baseq2/players/ogro
Model Author		: Magarnigal
			  email		:mellor@netgazer.net.au
			  homepage 	:http://magarn.3dpalette.com
Skins Author            : Ogro_Fix 
			  email		: ogro_fix@yahoo.com
			  homepage	: http://www.fondation.com/pandemonium
Additional info		: Fix has included a cloth and ogrobase skin that people may use as a base for skinning ogro.  The
			  mapping can be a bit confusing, 2d skinners beware.
Additional skin by	: Deranged - (Sharokh)
			  email		: deranged@deathsdoor.com
			  homepage 	: http://www.gibbed.com/thebin