-blink.jpg
-gbulb-mask.jpg
-santahelper_candy.md5mesh
-santahelper_candy_yaw.md5anim
-santahelper_giftbox.md5mesh
-santahelper_globebulb.md5mesh
-unknown.png
-white.jpg
	by @SalatielSauer (CC BY-SA 3.0)

-santahelper_giftbag.md5mesh
	-santaelf_giftbag
		by @SalatielSauer (CC BY-SA 3.0)

	-santaelf_gift_1 (tentus/bombs)
	-santaelf_gift_2 (tentus/hammer)
	-santaelf_gift_3 (tentus/food-drink/winebottle)
		by Tentus entrunner7@aol.com

-beard.png
-candy.jpg
-candy-mask.jpg
-gbulb.jpg
-giftbag.png
-lights.png
-lights-mask.jpg
-wreath.png
	from multiple sources (AdobeStock, freetextures.com, freepik.com) for non-commercial use, adapted by @SalatielSauer