-------------------------------------------------------------

Captain Cannon is hereby released under the CC-BY-NC (Creative Commons Attribution Non-Commercial) license.

See http://creativecommons.org/licenses/by-nc/3.0/legalcode for more info. 

Please contact Geartrooper for permission for uses not within the scope of this license.

//
	adaptation: 21/03/2019
	CaptainCannonIron is an adaptation.
	Although the original author has not been contacted, this adaptation is under (and following) the same terms mentioned above.
	The following aspects have been modified:
		- Cape and legs were completely removed.
		- IronSnoutx10k armor has been added (see terms below).
//
	
-------------------------------------------------------------

IronSnout X10K is hereby released under the following license:

(C) John 'geartrooper' Siar

License: CC-BY 3.0 http://creativecommons.org/licenses/by/3.0/

Please contact Geartrooper for permission for uses not within the scope of this license.

//
	adaptation: 21/03/2019
	Parts of this model are included in the CaptainCannonIron adaptation (see terms above).
	Although the original author has not been contacted, this adaptation is under (and following) the same terms mentioned above.
	The following aspects have been modified:
		- All influence weights have been replaced.
		- The internal area of ​​the head (helmet) has been removed.
		- Legs and arms were removed.
//

-------------------------------------------------------------
